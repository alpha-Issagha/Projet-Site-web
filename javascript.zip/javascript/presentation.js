function play(idPlayer, control) {//1
    var player = document.querySelector('#' + idPlayer);
	
    if (player.paused) {
        player.play();
        control.textContent = 'Pause';
    } else {
        player.pause();	
        control.textContent = 'Play';
    }
}

function resume(idPlayer) {
    var player = document.querySelector('#' + idPlayer);
	
    player.currentTime = 0;
    player.pause();
}

//2
function update(player) {
    var duration = player.duration;    // Durée totale
    var time     = player.currentTime; // Temps écoulé
    var fraction = time / duration;
    var percent  = Math.ceil(fraction * 100);

    var progress = document.querySelector('#progressBar');
	
    progress.style.width = percent + '%';
    progress.textContent = percent + '%';
}
function heure()
{
	time = new Date;
	heure = time.getHoures();
	min = time.getMinutes();
	sec = time.getSeconds();
	jr = time.getDate();
	ms = time.getMonth()+1;
	ans = time.getFullYear();
    if(sec < 10)
    	sec0= "0";
    else
    	sec0= "";
    if( min < 10)
    	min0="0";
    else
    	min0= "";
    if(heure < 10)
    	heure0= "0";
    else
    	heure0= "";
}

