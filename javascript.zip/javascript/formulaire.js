function coulr() {

	var cl=document.forms["form"].coul.value;
	document.forms["form"].field.style.backgroundColor=cl;
	
}
function ages(){
	var age1=document.forms["form"].annee.value;
	if(age1<1950)
		{alert("Vous avez depassez l'âge maximum (70ans) pour visiter notre site web! Merci pour la comprehension");
         	document.forms["form"].age2.value="";
        }
	else
		if (age1>2010)
		{alert("Vous n'avez pas encore atteint l'âge minimum (10ans) pour visiter notre site web! Merci pour la comprehension");
        document.forms["form"].age2.value="";
        }
        else
          if(age1=="")
            alert("Entrez votre âge !!!")
        else
        {
	var ag=2020 - parseInt(age1);

	document.forms["form"].age2.value=ag;
       }
}  

function valider(){
	  var res= true;
      var nom=document.forms["form"].elements["nom"].value;
     var prenom=document.getElementById('Prenom').value;
      var adresse=document.forms["form"].Adresse.value;
      var code=document.forms["form"].Cp.value;
      var ville=document.forms["form"].Ville.value;
      var tel=document.forms["form"].tel.value;
      var mail=document.forms["form"].mail.value;
      var jour=document.forms["form"].jour.value;
      var annee=document.forms["form"].annee.value;
      var mois= document.forms["form"].mois.value;

  if (nom=="") {
  	res=false; alert("Remplissez le champ nom");
  }
  else if (prenom=="") {
  	res=false; alert("Remplissez le champ prénom");
  }
   else if (jour=="") {
  	res=false; alert("Ajoutez votre jour de naissance");}
  	 else if (mois=="") {
  	res=false; alert("Ajoutez votre mois de naissance");}
  	else if (annee=="") {
  	res=false; alert("Ajoutez votre année de naissance");}
    else if (adresse=="") {
  	res=false; alert("Remplissez le champ adresse");}
   else if (code=="") {
  	res=false; alert("Remplissez le champ Code postal");
  }	
   else if (Ville=="") {
   res=false; alert("Remplissez le champ Ville");
  }
   else if (tel=="") {
   res=false; alert("Remplissez le champ téléphone");
  }
   else if (mail=="") {
  	res=false; alert("Remplissez le champ Email");
  }
  if (res==true) 
    {alert("Formulaire remplit avec succés!");}
 return res; 
 	
}


